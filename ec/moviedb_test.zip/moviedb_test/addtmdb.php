<html>
	<head>
		<title>tmdb test page</title>
	</head>
	<body>
		<form id="form1" name="form1" action="selector.php" method="post">
			<fieldset>
				<legend>
					Internet Movie Search
				</legend>
				<label>Enter movie title:</label>
				<br />
				<input type="text" width="400" name="title" id="title" value="" >
				<input type="submit" id="btnSearch" name="submit" value="Search"/>
			</fieldset>
		</form>
	</body>
</html>