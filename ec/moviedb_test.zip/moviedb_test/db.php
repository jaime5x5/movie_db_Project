<?php  
	$conn = mysqli_connect("localhost", "root", "YOUR PW HERE", "cs378_project");
	 if (!$conn)
    {
	 die('Could not connect: ' . mysqli_error());
	}
	mysqli_select_db($conn,"movies");
?>

