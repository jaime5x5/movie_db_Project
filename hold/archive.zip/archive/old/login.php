﻿<?php 

?>

<html>
<head>
<title>login</title>
<meta content="text/html; charset=UTF-8" http-equiv="content-type">
</head>
	<body class="">
		<form action="mvdbDisplay.html">
			<div>
		    	<label for="uname">User Name:</label>
		    	<input type="text" name="uname" id="uname" placeholder="enter user name" value="" />
		  	</div>
		  	<div>
		    	<label for="pwd">User Name:</label>
		    	<input type="text" name="pwd" id="pwd" placeholder="enter user password" value="" />
		  	</div>
			<div>
		    	<input type="submit" value="LOGIN" />
		  	</div>
		</form>
	</body>
</html>

